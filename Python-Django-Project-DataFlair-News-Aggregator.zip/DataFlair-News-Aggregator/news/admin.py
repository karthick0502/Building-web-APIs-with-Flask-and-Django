from django.contrib import admin
from news.models import Headline
# Register your models here.

admin.site.register(Headline)
