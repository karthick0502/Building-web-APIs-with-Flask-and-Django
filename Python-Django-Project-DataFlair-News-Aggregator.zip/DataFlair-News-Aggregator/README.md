# DataFlair-News-Aggregator
This Web application scrapes news articles from websites like theonion.com and present it in a webpage. This webapp combines the concept of django with web crawling. 
Check out the blogs on DataFlair Website
this project is explained on the platform DataFlair
# This project is developed by Karan Mittal
# Here is the link
