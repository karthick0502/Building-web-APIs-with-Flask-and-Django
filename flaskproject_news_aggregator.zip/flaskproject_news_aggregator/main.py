from flask import Flask, render_template, url_for
from scrap import bbc_scrap, toi_scrap
app = Flask(__name__)

bbc_news = bbc_scrap()
toi_news = toi_scrap()


@app.route('/')
@app.route('/bbc')
def bbc():
    return render_template('bbc.html', bbc_news=bbc_news)


@app.route('/toi')
def toi():
    return render_template('toi.html', toi_news=toi_news)


if __name__ == '__main__':
    app.run(debug=True)